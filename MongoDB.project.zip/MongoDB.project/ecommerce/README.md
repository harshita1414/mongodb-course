# E-Commerce Backend Application

## Project Overview

This is a backend E-Commerce application developed using Spring Boot and MongoDB. The project provides REST APIs for managing categories, products, customers, and orders. It follows a layered architecture consisting of Controller, Service, Repository, and Database layers.

---

## Features

* Category Management

  * Create Category
  * View Categories
  * Update Category
  * Delete Category

* Product Management

  * Create Product
  * View Products
  * Update Product
  * Delete Product
  * Search Products

* Customer Management

  * Create Customer
  * View Customers
  * Update Customer
  * Delete Customer

* Order Management

  * Create Orders
  * View Orders
  * Update Orders
  * Delete Orders

---

## Technology Stack

* Java 17
* Spring Boot
* Spring Data MongoDB
* MongoDB
* Maven
* Postman
* VS Code

---

## Project Structure

com.harshita.ecommerce

* controller
* service
* repository
* model
* dto
* exception
* config

---

## Architecture

Controller → Service → Repository → MongoDB

---

## Database Collections

* Categories
* Products
* Customers
* Orders

---

## API Endpoints

### Categories

* POST /categories
* GET /categories
* PUT /categories/{id}
* DELETE /categories/{id}

### Products

* POST /products
* GET /products
* PUT /products/{id}
* DELETE /products/{id}

### Customers

* POST /customers
* GET /customers
* PUT /customers/{id}
* DELETE /customers/{id}

### Orders

* POST /orders
* GET /orders
* GET /orders/{id}
* PUT /orders/{id}
* DELETE /orders/{id}

---

## Testing

All APIs were tested using Postman and data was stored in MongoDB.

---

## Author

Harshita Sonwani
