package com.harshita.ecommerce.repository;

import com.harshita.ecommerce.model.Product;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;
import org.springframework.data.domain.Sort;

public interface ProductRepository
        extends MongoRepository<Product, String> {

    List<Product> findByCategoryId(String categoryId);
    List<Product> findByNameContainingIgnoreCase(String name);
    List<Product> findAll(Sort sort);

}
