package com.harshita.ecommerce.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.harshita.ecommerce.model.Category;

public interface CategoryRepository extends MongoRepository<Category, String> {

}