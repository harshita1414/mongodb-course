package com.harshita.ecommerce.controller;

import com.harshita.ecommerce.model.Product;
import com.harshita.ecommerce.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping
    public Product addProduct(@Valid @RequestBody Product product) {
        return productService.addProduct(product);
    }

    @GetMapping
    public List<Product> getAllProducts() {
        return productService.getAllProducts();
    }

    @GetMapping("/{id}")
    public Product getProductById(@PathVariable String id) {
        return productService.getProductById(id);
    }

    @GetMapping("/category/{categoryId}")
    public List<Product> getProductsByCategory(
            @PathVariable String categoryId) {

        return productService.getProductsByCategory(categoryId);
    }

    @GetMapping("/search/{name}")
    public List<Product> searchProducts(@PathVariable String name) {
        return productService.searchProducts(name);
    }

    @GetMapping("/sort/asc")
    public List<Product> getProductsAscending() {
        return productService.getProductsAscending();
    }

    @GetMapping("/sort/desc")
    public List<Product> getProductsDescending() {
        return productService.getProductsDescending();
    }

    @DeleteMapping("/{id}")
    public String deleteProduct(@PathVariable String id) {
        productService.deleteProduct(id);
        return "Product deleted successfully";
    }

    @PutMapping("/{id}")
    public Product updateProduct(@PathVariable String id,
            @RequestBody Product product) {
        return productService.updateProduct(id, product);
    }
}
