package com.harshita.ecommerce.service;

import java.util.Optional;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.harshita.ecommerce.model.Category;
import com.harshita.ecommerce.repository.CategoryRepository;

@Service
public class CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    public Category createCategory(Category category) {
        return categoryRepository.save(category);
    }

    public List<Category> getAllCategories() {
        return categoryRepository.findAll();
    }

    public void deleteCategory(String id) {
        categoryRepository.deleteById(id);
    }

    public Category updateCategory(String id, Category category) {

        Optional<Category> existingCategory = categoryRepository.findById(id);

        if (existingCategory.isPresent()) {

            Category updatedCategory = existingCategory.get();

            updatedCategory.setName(category.getName());
            updatedCategory.setDescription(
                    category.getDescription());

            return categoryRepository.save(updatedCategory);
        }

        return null;
    }

}
