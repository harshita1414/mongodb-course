package com.harshita.ecommerce.service;

import com.harshita.ecommerce.model.Order;
import com.harshita.ecommerce.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    public Order addOrder(Order order) {
        return orderRepository.save(order);
    }

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    public Order getOrderById(String id) {
        return orderRepository.findById(id).orElse(null);
    }

    public Order updateOrder(String id, Order order) {

        Order existingOrder = orderRepository.findById(id).orElse(null);

        if (existingOrder != null) {

            existingOrder.setCustomerId(order.getCustomerId());
            existingOrder.setOrderItems(order.getOrderItems());

            return orderRepository.save(existingOrder);
        }

        return null;
    }

    public void deleteOrder(String id) {
        orderRepository.deleteById(id);
    }
}
